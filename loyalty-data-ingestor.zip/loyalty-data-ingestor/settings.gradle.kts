rootProject.name = "loyalty-data-ingestor"
