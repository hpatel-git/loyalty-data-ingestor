package com.lowes.daci.mkt.loyalty

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LoyaltyDataIngestorApplication

fun main(args: Array<String>) {
	runApplication<LoyaltyDataIngestorApplication>(*args)
}
