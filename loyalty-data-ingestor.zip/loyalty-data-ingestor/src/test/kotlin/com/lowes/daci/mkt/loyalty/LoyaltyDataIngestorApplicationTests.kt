package com.lowes.daci.mkt.loyalty

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LoyaltyDataIngestorApplicationTests {

	@Test
	fun contextLoads() {
	}

}
